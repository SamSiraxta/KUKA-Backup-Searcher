package pckg.Extract;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Extracter {

	public ArrayList<String> dirTree = new ArrayList<String>();

	public void unzipFile(String zipFilePath, String destDirectory) throws IOException {

		// Generate a stream entry
		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
		ZipEntry entry = zipIn.getNextEntry();

		// Iterate over entries
		while (entry != null) {
			String filePath = destDirectory + File.separator + entry.getName();

			// Depending on what's inside, extracts a file and makes new directories
			if (!entry.isDirectory()) {
				extractFile(zipIn, filePath);
			} else {
				File dir = new File(filePath);
				dir.mkdir();
				extractFile(zipIn, filePath);
			}

			// Go to next entry
			zipIn.closeEntry();
			entry = zipIn.getNextEntry();
		}
		zipIn.close();
	}

	public String getDir(String filePath) {

		String fileDir = "";
		int pointIndex = filePath.indexOf(".");
		int SepIndex = 0;
		boolean StopCont = false;
		char pointer;

		// Get index of last separator
		for (int count = pointIndex; count >= 0; count--) {
			pointer = filePath.charAt(count);
			if (pointer == '\\' && !StopCont) {
				SepIndex = count;
				StopCont = true;
			}
		}

		// Get path of directory without file name
		fileDir = filePath.substring(0, SepIndex);
		return fileDir;
	}
	
	public void extractFile(ZipInputStream zipIn, String filePath) throws IOException {

		// Get path and file
		String fileDir = "";
		filePath = filePath.replace("/", "\\");
		fileDir = getDir(filePath);

		final int BUFFER_SIZE = 1024;
		File filePathDest = new File(filePath);
		new File(fileDir).mkdirs();

		// Add filePath to DIR tree
		dirTree.add(filePath);

		// Extract data
		BufferedOutputStream zipExtracted = new BufferedOutputStream(new FileOutputStream(filePathDest));
		byte[] bytesIn = new byte[BUFFER_SIZE];

		// Writes data
		int read = 0;
		while ((read = zipIn.read(bytesIn)) != -1) {
			zipExtracted.write(bytesIn, 0, read);
		}
		zipExtracted.close();
	}
	
	public ArrayList<String> getDirTree() {
		return dirTree;
	}

	public void setDirTree(ArrayList<String> dirTree) {
		this.dirTree = dirTree;
	}
}