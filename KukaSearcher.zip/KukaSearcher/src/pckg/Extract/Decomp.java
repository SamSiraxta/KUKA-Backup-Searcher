package pckg.Extract;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import pckg.Extract.Extracter;

public class Decomp {

	Extracter extracter = new Extracter();
	
	public void extracterZip(String zipFilePath, String destDirectory) {
		
		// Extract KUKA Backup
		try {
			extracter.unzipFile(zipFilePath, destDirectory);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void setDirTree (String mainPath, String mainName) {
		
		ArrayList<String> dirTree = new ArrayList<String>();
		
		// Build DIR tree
		dirTree = extracter.getDirTree();
		new File(mainPath).mkdirs();
		File fileList = new File(mainPath + "\\" + mainName + ".dt");
		
		// Write data
		FileWriter fileWriter;
		try {
			
			fileWriter = new FileWriter(fileList);
			for (String item : dirTree) {
                 fileWriter.write(item);
                 fileWriter.write(System.getProperty("line.separator"));
			}
			
			fileWriter.flush();
			fileWriter.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		// Clean ArrayList
		dirTree.clear();
		extracter.setDirTree(dirTree);
		extracter = null;
	}
}
