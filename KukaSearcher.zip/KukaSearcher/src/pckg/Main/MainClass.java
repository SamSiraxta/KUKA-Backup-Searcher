package pckg.Main;

import java.io.File;
import pckg.Extract.Decomp;
import pckg.GUI.GUI;
import pckg.GUI.JFramer;

public class MainClass {
	
	public void UnZipper() {

		Decomp unZipper = new Decomp();
		if (JFramer.sTextPath != null) {

			// Get the name of the ZIP file and make DIR
			int PointIndex = JFramer.sTextName.indexOf(".");
			String mainName = JFramer.sTextName.substring(0, PointIndex);
			new File(System.getProperty("user.dir") + "\\decomp\\").mkdirs();
	
			// Extract data and generate DIR tree
			unZipper.extracterZip(JFramer.sTextPath, System.getProperty("user.dir") + "\\decomp\\" + mainName);
		    unZipper.setDirTree(System.getProperty("user.dir") + "\\dirtree\\", mainName);
		}
	}

	// Call GUI
	public static void main(String[] args) {
		GUI visualInterface = new GUI();
		visualInterface.guiRUN(args);
	}
}