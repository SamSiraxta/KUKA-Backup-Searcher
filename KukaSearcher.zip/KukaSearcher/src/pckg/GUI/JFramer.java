package pckg.GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import pckg.Main.MainClass;
import pckg.Read.Read;

public class JFramer extends JFrame implements ActionListener {

	// Declare variables
	JLabel Title, Credits;
	JButton OpenButton;
	JButton SearchButton;
	JScrollPane scrollPaneArea;
	JPopupMenu popup;
	Image icon;
	JTextField textField;
	JTextArea textArea;
	private Container cContainer;

	public static String sTextName, sTextPath;
	private static final long serialVersionUID = 1L;

	// Constructor
	public JFramer() {

		// Get container
		cContainer = getContentPane();
		cContainer.setLayout(null);

		// Generate a textField
		textField = new JTextField();
		textField.setBounds(180, 21, 467, 20);
		add(textField);

		// Set the Title label
		Font fontLabel = new Font("Gobold", Font.BOLD, 12);
		Title = new JLabel();
		Title.setText("KUKA BACKUP SEARCHER");
		Title.setFont(fontLabel);
		Title.setBounds(20, 20, 180, 23);

		// Set the Title label
		Credits = new JLabel();
		Credits.setText("Designed by SamSiraxta");
		Credits.setFont(fontLabel);
		Credits.setBounds(830, 20, 180, 23);

		// Define texts on area
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);

		// Sets JTextArea font and color.
		Font fontScroll = new Font("Helvetica", Font.BOLD, 12);
		textArea.setFont(fontScroll);
		textArea.setForeground(Color.BLACK);

		// Define scroll Panel
		scrollPaneArea = new JScrollPane(textArea);
		scrollPaneArea.setBounds(18, 50, 950, 600);
		scrollPaneArea.setViewportView(textArea);

		// Set open button attributes
		OpenButton = new JButton();
		OpenButton.setText("Open");
		OpenButton.setBounds(655, 19, 80, 23);
		OpenButton.addActionListener(this);

		// Set save button attributes
		SearchButton = new JButton();
		SearchButton.setText("Find");
		SearchButton.setBounds(740, 19, 80, 23);
		SearchButton.addActionListener(this);

		// Add instances to container
		cContainer.add(Title);
		cContainer.add(Credits);
		cContainer.add(scrollPaneArea);
		cContainer.add(OpenButton);
		cContainer.add(SearchButton);

		// Set title
		setTitle("KUKA BACKUP SEARCHER v0.1");
		setSize(1000, 700);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	// Event performed
	@Override
	public void actionPerformed(ActionEvent event) {

		MainClass mainC = new MainClass();

		// First event (Extract BackUp)
		if (event.getSource() == OpenButton) {
			String fileName = openFile();

			// Check if selected file is ZIP
			int intIndex = fileName.indexOf(".zip");

			if (intIndex == -1) {
				JOptionPane.showMessageDialog(null, "Select a .ZIP file!", "Error Message", JOptionPane.ERROR_MESSAGE);
			} else {
				mainC.UnZipper();
				JOptionPane.showMessageDialog(null, "Unzipping finished!", "Info Message",
						JOptionPane.INFORMATION_MESSAGE);
			}
		}

		// Second event (Read Backup)
		if (event.getSource() == SearchButton) {
			searchCode();
		}
	}

	private String openFile() {

		sTextName = "";

		// Open the dialog up
		JFileChooser jFile = new JFileChooser(System.getProperty("user.home") + "\\Desktop");
		jFile.showSaveDialog(this);

		// Get the selected file
		File fileSelected = jFile.getSelectedFile();

		// Get the path of selected file
		if (fileSelected != null) {
			sTextName = jFile.getSelectedFile().getName();
		}

		return sTextName;
	}

	private void searchCode() {

		Read readObj = new Read();
		String sTextPathLocal = "";
		String sTextNameLocal = "";

		// Clean the scroll panel
		textArea.setText("");

		// Open the dialog up
		JFileChooser jFile = new JFileChooser(System.getProperty("user.dir") + "\\dirtree");
		jFile.showSaveDialog(this);

		// Get the selected file
		File fileSelected = jFile.getSelectedFile();

		// Get the path of selected file
		if (fileSelected != null) {
			sTextNameLocal = jFile.getSelectedFile().getName();
			sTextPathLocal = jFile.getSelectedFile().getAbsolutePath();
		}

		// Check if .DT file was created
		if (sTextNameLocal.contains(".dt")) {

			// Pass parameters
			readObj.readRun(sTextPathLocal, textField.getText());

			// Show the result
			for (String item : readObj.getHistory()) {
				textArea.append(item);
			}

			// Clean history to use it once again
			readObj.setHistory();
			readObj = null;

			// End the showing
			JOptionPane.showMessageDialog(null, "Search already done!", "Info Message",
					JOptionPane.INFORMATION_MESSAGE);

		} else {
			JOptionPane.showMessageDialog(null, "ERROR -> Select a .DT file!", "Error Message",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}