package pckg.GUI;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;
import pckg.GUI.JFramer;

public class GUI {

	public void guiRUN(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					JFramer frame = new JFramer();
					
					// Generate GUI and image icon
					Image icon = Toolkit.getDefaultToolkit().getImage("Image\\icon.png");
					frame.setIconImage(icon);
					frame.setResizable(false);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}