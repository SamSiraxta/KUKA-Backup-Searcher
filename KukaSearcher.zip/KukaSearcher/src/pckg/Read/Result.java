package pckg.Read;

import java.util.ArrayList;

public class Result {

	ArrayList<String> linesFound = new ArrayList<String>();
	ArrayList<String> fileFound = new ArrayList<String>();
	ArrayList<Integer> nLineFound = new ArrayList<Integer>();
	
	// Method to know in which line and number of line I found the keyword
	public void lineFound(String line, int nLineFnd) {
		linesFound.add(line);
		nLineFound.add(nLineFnd);
	}
	
	// Method to know what's the path of the file
	public void fileFinding(String fileLinePath) {
		fileFound.add(fileLinePath);
	}
	
	// Method to clean up
	public void cleanUp() {
		fileFound.clear();
		nLineFound.clear();
		linesFound.clear();
	}
	
	// Getters //
	public String getLinesFound(int Index) {
		return linesFound.get(Index);
	}

	public int getnLineFound(int Index) {
		return nLineFound.get(Index);
	}
	
	public String getFileFound(int Index) {
		return fileFound.get(Index);
	}
	
	public int getSize() {
		return nLineFound.size();
	}
}