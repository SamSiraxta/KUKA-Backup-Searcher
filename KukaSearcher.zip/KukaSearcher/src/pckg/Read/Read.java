package pckg.Read;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class Read {

	ArrayList<String> history = new ArrayList<String>();

	public void readRun(String sTextPath, String textField) {

		// Pass the paths' List to the file as a parameter
		File file = new File(sTextPath);
		boolean Stop = false;
		try {

			// Scan DIR tree to open new files up
			Scanner scFile = new Scanner(file);

			while (scFile.hasNextLine() && !Stop) {
				String fileLine = scFile.nextLine();
				if (fileLine == "") {
					Stop = true;
				}
				lookUp(fileLine, textField);
			}
			scFile.close();
			
			// Make History folder and file
			if (textField.length() != 0) {
				new File(System.getProperty("user.dir") + "\\history\\").mkdirs();
				String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
				File fileHistory = new File(System.getProperty("user.dir") + "\\history\\" + timeStamp + "_"
						+ textField + ".txt");

				// Write search info
				FileWriter fileWriter;
				try {

					fileWriter = new FileWriter(fileHistory);
					for (String item : history) {
						fileWriter.write(item);
						fileWriter.write(System.getProperty("line.separator"));
					}

					fileWriter.flush();
					fileWriter.close();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// Look for the keyword inside of the file
	public void lookUp(String fileLinePath, String textField) {

		Result resultP = new Result();
		
		File file = new File(fileLinePath);
		boolean foundKey = false;

		try {
			Scanner scanner = new Scanner(file);
			int lineNum = 0;

			// Now read the file line by line...
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				lineNum++;

				// Look up the keyword among the line
				if ((textField.length() != 0)
						&& line.toLowerCase().contains(textField.toLowerCase())) {
					foundKey = true;
					resultP.lineFound(line, lineNum);
					resultP.fileFinding(fileLinePath);
				}
			}
			scanner.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		// Add results
		if (foundKey) {
			history.add("\n");
			history.add("\nFile Path -> " + fileLinePath);

			for (int count = 0; count < resultP.getSize(); count++) {
				history.add("\nN� " + resultP.getnLineFound(count) + ": " + resultP.getLinesFound(count));
			}

			// Remove the object
			resultP.cleanUp();
			resultP = null;
		}
	}
	
	//Getter and Setter//
	public ArrayList<String> getHistory() {
		return history;
	}

	public void setHistory() {
		history.clear();
	}
}